# AI Health Chatbot

## Overview
The AI Health Chatbot is an interactive application designed to provide users with information about various diseases, including symptoms, prevention methods, and treatment options. The chatbot leverages AI technology to understand user queries and deliver accurate responses, promoting disease awareness and health education.

## Project Structure
```
ai-health-chatbot
├── src
│   ├── index.js
│   ├── chatbot
│   │   ├── botEngine.js
│   │   └── responses.js
│   ├── data
│   │   └── diseases.json
│   ├── services
│   │   └── aiService.js
│   ├── utils
│   │   └── helpers.js
│   └── config
│       └── settings.js
├── public
│   ├── index.html
│   ├── styles.css
│   └── chatbot.js
├── tests
│   ├── botEngine.test.js
│   └── aiService.test.js
├── package.json
├── .gitignore
└── README.md
```

## Installation
1. Clone the repository:
   ```
   git clone https://github.com/yourusername/ai-health-chatbot.git
   ```
2. Navigate to the project directory:
   ```
   cd ai-health-chatbot
   ```
3. Install the dependencies:
   ```
   npm install
   ```

## Usage
1. Start the application:
   ```
   npm start
   ```
2. Open your browser and go to `http://localhost:3000` to interact with the chatbot.

## Features
- AI-driven responses based on user queries.
- Information on various diseases, including symptoms and treatment options.
- User-friendly interface for easy interaction.

## Contributing
Contributions are welcome! Please open an issue or submit a pull request for any enhancements or bug fixes.

## License
This project is licensed under the MIT License. See the LICENSE file for details.