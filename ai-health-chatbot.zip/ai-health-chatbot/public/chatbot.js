// This file contains the JavaScript code for the frontend chatbot functionality, handling user interactions and displaying responses.

document.addEventListener("DOMContentLoaded", function() {
    const userInput = document.getElementById("user-input");
    const sendButton = document.getElementById("send-button");
    const chatWindow = document.getElementById("chat-window");

    sendButton.addEventListener("click", function() {
        const userMessage = userInput.value;
        if (userMessage.trim() === "") return;

        appendMessage("User: " + userMessage);
        userInput.value = "";

        fetchResponse(userMessage);
    });

    function appendMessage(message) {
        const messageElement = document.createElement("div");
        messageElement.textContent = message;
        chatWindow.appendChild(messageElement);
    }

    function fetchResponse(message) {
        fetch("/api/chatbot", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ message: message })
        })
        .then(response => response.json())
        .then(data => {
            appendMessage("Bot: " + data.response);
        })
        .catch(error => {
            console.error("Error:", error);
            appendMessage("Bot: Sorry, I couldn't process your request.");
        });
    }
});