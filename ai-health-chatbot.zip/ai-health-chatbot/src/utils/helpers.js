export function validateInput(input) {
    if (typeof input !== 'string' || input.trim() === '') {
        return false;
    }
    return true;
}

export function formatResponse(response) {
    return response.charAt(0).toUpperCase() + response.slice(1);
}

export function extractKeywords(input) {
    return input.split(' ').filter(word => word.length > 2);
}