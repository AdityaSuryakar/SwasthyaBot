const responses = {
    greeting: "Hello! I'm your health assistant. How can I help you today?",
    farewell: "Thank you for chatting with me. Stay healthy!",
    diseaseInfo: (disease) => `Here is some information about ${disease}: ...`,
    symptoms: (disease) => `Common symptoms of ${disease} include: ...`,
    prevention: (disease) => `To prevent ${disease}, you should: ...`,
    treatment: (disease) => `Treatment options for ${disease} include: ...`,
    unknown: "I'm sorry, I didn't understand that. Can you please rephrase?",
};

export default responses;