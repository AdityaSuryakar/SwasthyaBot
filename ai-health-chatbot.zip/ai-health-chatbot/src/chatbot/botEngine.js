// File: /ai-health-chatbot/ai-health-chatbot/src/chatbot/botEngine.js

const responses = require('./responses');
const diseasesData = require('../data/diseases.json');

class Chatbot {
    constructor() {
        this.intents = {
            greeting: ['hello', 'hi', 'hey'],
            diseaseInquiry: ['symptoms of', 'what is', 'tell me about'],
            preventionInquiry: ['how to prevent', 'preventing'],
            treatmentInquiry: ['treatment for', 'how to treat']
        };
    }

    handleUserInput(input) {
        const lowerInput = input.toLowerCase();
        
        if (this.isGreeting(lowerInput)) {
            return responses.greetUser();
        } else if (this.isDiseaseInquiry(lowerInput)) {
            return this.handleDiseaseInquiry(lowerInput);
        } else if (this.isPreventionInquiry(lowerInput)) {
            return this.handlePreventionInquiry(lowerInput);
        } else if (this.isTreatmentInquiry(lowerInput)) {
            return this.handleTreatmentInquiry(lowerInput);
        } else {
            return responses.defaultResponse();
        }
    }

    isGreeting(input) {
        return this.intents.greeting.some(greet => input.includes(greet));
    }

    isDiseaseInquiry(input) {
        return this.intents.diseaseInquiry.some(intent => input.includes(intent));
    }

    isPreventionInquiry(input) {
        return this.intents.preventionInquiry.some(intent => input.includes(intent));
    }

    isTreatmentInquiry(input) {
        return this.intents.treatmentInquiry.some(intent => input.includes(intent));
    }

    handleDiseaseInquiry(input) {
        const diseaseName = this.extractDiseaseName(input);
        const diseaseInfo = diseasesData[diseaseName];
        return diseaseInfo ? responses.diseaseInfo(diseaseInfo) : responses.unknownDisease();
    }

    handlePreventionInquiry(input) {
        const diseaseName = this.extractDiseaseName(input);
        const diseaseInfo = diseasesData[diseaseName];
        return diseaseInfo ? responses.preventionInfo(diseaseInfo) : responses.unknownDisease();
    }

    handleTreatmentInquiry(input) {
        const diseaseName = this.extractDiseaseName(input);
        const diseaseInfo = diseasesData[diseaseName];
        return diseaseInfo ? responses.treatmentInfo(diseaseInfo) : responses.unknownDisease();
    }

    extractDiseaseName(input) {
        const words = input.split(' ');
        return words.find(word => diseasesData[word]) || '';
    }
}

module.exports = new Chatbot();