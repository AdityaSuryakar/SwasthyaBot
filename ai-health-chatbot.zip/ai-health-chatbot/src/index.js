// This file is the entry point of the application. It initializes the server and sets up routes for the chatbot.

const express = require('express');
const bodyParser = require('body-parser');
const chatbotRoutes = require('./chatbot/botEngine');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.use('/api/chat', chatbotRoutes);

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});