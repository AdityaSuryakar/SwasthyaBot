// src/services/aiService.js

const fetch = require('node-fetch');

const AI_API_URL = 'https://api.example.com/ai'; // Replace with actual AI API URL

async function getAIResponse(userInput) {
    try {
        const response = await fetch(AI_API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ query: userInput }),
        });

        if (!response.ok) {
            throw new Error('Network response was not ok');
        }

        const data = await response.json();
        return data.response; // Adjust based on actual API response structure
    } catch (error) {
        console.error('Error fetching AI response:', error);
        throw error;
    }
}

module.exports = {
    getAIResponse,
};