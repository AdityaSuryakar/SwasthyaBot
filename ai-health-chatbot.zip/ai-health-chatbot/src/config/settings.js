const config = {
    apiKey: "YOUR_API_KEY_HERE",
    apiUrl: "https://api.example.com",
    environment: process.env.NODE_ENV || "development",
    port: process.env.PORT || 3000,
};

export default config;