const { getResponse } = require('../src/chatbot/botEngine');

describe('Bot Engine', () => {
    test('should return a response for a known disease query', () => {
        const userInput = 'Tell me about diabetes';
        const expectedResponse = 'Diabetes is a chronic disease that occurs when the body cannot produce enough insulin...'; // Example response
        const response = getResponse(userInput);
        expect(response).toBe(expectedResponse);
    });

    test('should return a default response for unknown queries', () => {
        const userInput = 'What is the weather today?';
        const expectedResponse = 'I am sorry, I can only provide information about diseases.';
        const response = getResponse(userInput);
        expect(response).toBe(expectedResponse);
    });

    test('should handle empty input gracefully', () => {
        const userInput = '';
        const expectedResponse = 'Please ask me about a disease or health-related topic.';
        const response = getResponse(userInput);
        expect(response).toBe(expectedResponse);
    });
});