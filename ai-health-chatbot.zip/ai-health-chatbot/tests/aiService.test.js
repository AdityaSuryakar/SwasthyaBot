const aiService = require('../src/services/aiService');

describe('AI Service', () => {
    test('should return relevant information for a known disease', async () => {
        const input = 'What are the symptoms of diabetes?';
        const expectedOutput = expect.any(Object); // Replace with actual expected output if known

        const result = await aiService.getDiseaseInfo(input);
        expect(result).toEqual(expectedOutput);
    });

    test('should handle unknown disease queries gracefully', async () => {
        const input = 'Tell me about an unknown disease';
        const expectedOutput = 'I am sorry, I do not have information on that disease.';

        const result = await aiService.getDiseaseInfo(input);
        expect(result).toEqual(expectedOutput);
    });

    test('should validate user input correctly', () => {
        const validInput = 'What should I do if I have a headache?';
        const invalidInput = '';

        expect(aiService.validateInput(validInput)).toBe(true);
        expect(aiService.validateInput(invalidInput)).toBe(false);
    });
});